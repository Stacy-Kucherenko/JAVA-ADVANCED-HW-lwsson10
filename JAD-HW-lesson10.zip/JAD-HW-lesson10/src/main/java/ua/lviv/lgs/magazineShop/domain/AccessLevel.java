package ua.lviv.lgs.magazineShop.domain;

public enum AccessLevel {
	USER, ADMIN
}
