package ua.lviv.lgs.magazineShop.dao;

import ua.lviv.lgs.magazineShop.domain.Magazine;

public interface MagazineDAO extends DAOAbstractCRUD<Magazine> {

}