package ua.lviv.lgs.magazineShop.dao;

import ua.lviv.lgs.magazineShop.domain.Subscribe;

public interface SubscribeDAO extends DAOAbstractCRUD<Subscribe> {

}