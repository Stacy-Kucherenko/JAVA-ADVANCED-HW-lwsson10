package ua.lviv.lgs.magazineShop.service;

import ua.lviv.lgs.magazineShop.dao.DAOAbstractCRUD;
import ua.lviv.lgs.magazineShop.domain.Subscribe;

public interface SubscribeService extends DAOAbstractCRUD<Subscribe> {

}
